const express = require("express");
const cors = require("cors");
const fs = require("fs");
const csv = require("csv-parser");
const path = require("path");

const app = express();
const PORT = 4000;

app.use(cors());

// load CSV once at startup
let sponsorshipData = [];

function loadData() {
  sponsorshipData = [];
  const filePath = path.join(__dirname, "data", "uganda_child_sponsorship_1000_records.csv");

  fs.createReadStream(filePath)
    .pipe(csv())
    .on("data", (row) => {
      sponsorshipData.push(row);
    })
    .on("end", () => {
      console.log(`Loaded ${sponsorshipData.length} records`);
    });
}

loadData();

// basic API to get all data (you can add filters later)
app.get("/api/sponsorship", (req, res) => {
  res.json(sponsorshipData);
});

app.listen(PORT, () => {
  console.log(`Backend API running on http://localhost:${PORT}`);
});
